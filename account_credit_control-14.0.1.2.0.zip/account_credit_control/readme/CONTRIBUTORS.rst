* Nicolas Bessi (Camptocamp)
* Guewen Baconnier (Camptocamp)
* Sylvain Van Hoof (Okia SPRL) <sylvain@okia.be>
* Akim Juillerat (Camptocamp) <akim.juillerat@camptocamp.com>
* Kinner Vachhani (Access Bookings Ltd) <kin.vachhani@gmail.com>
* Raf Ven <raf.ven@dynapps.be>
* Quentin Groulard (ACSONE) <quentin.groulard@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Vicent Cubells
  * Manuel Calero
  * Ernesto Tejeda
  * Pedro M. Baeza
  * Jairo Llopis
  * João Marques

* Enric Tobella <etobella@creublanca.es>
* Naglis Jonaitis (Versada UAB) <naglis@versada.eu>
